del /Q .\signed\LW5xx\*.*
del /Q .\signed\LW5xx\amd64\*.*
del /Q .\signed\LW5xx\i386\*.*

mkdir .\signed\LW5xx\amd64
mkdir .\signed\LW5xx\i386

copy ..\..\Inf\LW5xx\*.* signed\LW5xx
copy ".\_bin\x64\Release\*.dll" .\signed\LW5xx\amd64
copy ".\_bin\Win32\Release\*.dll" .\signed\LW5xx\i386

Powershell.exe -executionpolicy remotesigned -File ..\..\..\..\Tools\Signing\UpdateInfVersion.ps1 .\signed\LW5xx\DYMO_LW5xx.inf 1.2.0.222
..\..\..\..\Tools\Signing\Inf2Cat.exe /uselocaltime /driver:signed\LW5xx /os:6_3_X86,6_3_X64
..\..\..\..\Tools\Signing\signtool.exe sign /f ..\..\..\..\Tools\Signing\Newell2025.pfx /p newell /as /fd sha256 /tr http://timestamp.digicert.com signed\LW5xx\dymo.cat
:: ..\..\..\..\Tools\Signing\InfVerif.exe .\signed\LW5xx\DYMO_LW5xx.inf
:: copy "src\labelwriter\lw5xx\5xx_*.cmd" signed\LW5xx
pause